using System;

namespace EffectiveDating.Core.Interceptors
{
    [AttributeUsage(AttributeTargets.Property)]
    public class TemporalProperty : Attribute
    {
    }
}